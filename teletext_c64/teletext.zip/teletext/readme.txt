
Teletext Reader for the Commodore 64
====================================

by Norbert Kehrer in January 2018



Installation
------------

Unzip the archive to a Windows directory. The directory should contain 3 files:
   - teletext_orf.exe (the page downloader for the ORF TV channels)
   - teletext_ard.exe (the page downloader for the ARD TV channel)
   - teletext_br.exe  (the page downloader for the Bayerischer Rundfunk TV channel)
   - teletext_zdf.exe (the page downloader for the ZDF TV channel)
   - teletext.prg (the C64 page reader)
   - curl.exe (a utility for file downloads)
   - readme.txt (this file)



How to run
----------

Step 1: Download all the teletext pages from the ORF site to the Windows PC
Step 2: Copy the files together with the reader program to an SD card
Step 3: Read the pages on the C64



Step 1: Downloading
-------------------

Open the command line in Windows and go to your teletext directory. Then,
start the downloader by typing "teletext_orf <channel> <format>", where
<channel> is one of
   - orf1          (for ORF eins)
   - orf2          (for ORF 2)
   - orfiii        (for ORF III)
   - orfsportplus  (for ORF Sport +) 

and <format> (the format of the file names for the C64) is one of
   - 1541u         (".prg" is added to each file name)
   - sd2iec        (".prg" is not added to the file names).

If you leave out one or both of the parameters, the defaults are "orf1" and "sd2iec",
respectively.

The program will then run for about 20 seconds up to maybe 5 to 10 minutes, download the
teletext pages from the ORF site for the respective channel, and convert them to
a C64 readable format. All these pages will be put into a subdirectory of your
teletext directory called "pages". The C64 reader programs you need will also be copied
to this subdirectory.

If you want to read the teletext pages of the German TV station ZDF, then
start the corresponding downloader with "teletext_zdf <channel> <format>", where
<channel> is one of
   - zdf          (for ZDF, the only one)

and <format> (the format of the file names for the C64) is one of
   - 1541u         (".prg" is added to each file name)
   - sd2iec        (".prg" is not added to the file names).

If you want to read the teletext pages of the German TV station ARD, then
start the corresponding downloader with "teletext_ard <channel> <format>", where
<channel> is one of
   - ard          (for ARD, the only one)

and <format> (the format of the file names for the C64) is one of
   - 1541u         (".prg" is added to each file name)
   - sd2iec        (".prg" is not added to the file names).

If you want to read the teletext pages of the German TV station BR (Bayerischer Rundfunk),
then start the corresponding downloader with "teletext_br <channel> <format>", where
<channel> is one of
   - br            (for BR, the only one)

and <format> (the format of the file names for the C64) is one of
   - 1541u         (".prg" is added to each file name)
   - sd2iec        (".prg" is not added to the file names).



Step 2: Copying files
---------------------

Copy all the files in the "pages" directory to an SD card. Connect the SD card
to your Commodore 64 via SD2IEC, 1541 Ultimate, Uno2IEC, or a similar hardware solution.




Step 3: Read on the Commodore 64
--------------------------------

On the C64 load and start the program "0teletext.prg" (or "0teletextu.prg" for the
1541 ultimate) now to read the downloaded teletext pages.
To dial a page, enter the 3-digit page number. You will see your entry in the bottom
left corner (to the right of the "Goto:"). To go to the selected page, press "Return",
then.
There are four convenience functions available with the C64 function keys:
   - f1: Go back to the last page you visited (history)
   - f3: Go to page 100 (often the home page of the teletext content of a TV station)
   - f5: Go to the previous page (previous subpage or previous available mainpage)
   - f7: Go to the next page (next subpage, or next available main page)



Have fun!

Norbert


 
 

