*************************************************************
*  VANTRIS - A Tetris Game For The Vanguard Arcade Machine  *
*************************************************************
*  programmed by Norbert Kehrer                             *
*  made in 1998 for hardware from 1981.                     *
*  norbert.kehrer@utanet.at   http://web.utanet.at/nkehrer  *
*************************************************************


Description

	Vantris is a Tetris clone running on the Vanguard
	hardware. It is written in 6502 assembler language
	and uses a completely new graphics set (no portions
	of the original Vanguard game are included).

	I thought a classic game runs best on a classic
	machine. It really is great fun to make new software
	for such old arcade machines.
	Thanks to the MAME team for their great emulation
	engines.

	This program was tested with the M.A.M.E. Emulator.
	It wonder if the program works on a real machine.
	Would someone who owns such a beast burn the software
	into a ROM and test it on the real hardware for which
	it was written.
	Let me know of your efforts.


Installation 

	Copy the file 'VANGUARD.ZIP' to the ROMS directory of 
	mame and type 'MAME VANGUARD'.


Playing Vantris 

	As usual on coin-ops you have to insert some coins with
	the key '3'. To start the game use key '1'. Movement of
	the blocks is done by the cursor keys. Turn the blocks
	with the fire button (Ctrl key).


Source code and reassembly

	The full source code is supplied in this package. You
	can reassemble it on your system with a 6502 assembler.
	Use the following object file names:
		Source		Object	
		vantris.as	sk4_ic13.bin
		vantrcl.as 	sk5_ic6.bin
		vantrcl.as	sk5_ic7.bin
		vantrs1.as 	sk4_ic51.bin
	The rest of the files needed by MAME may contain $00
	or any other arbitray values but need to have the
	correct size.


Acknowledgements

	Thanks to the MAME developers, I got all my info from
	their source code:
		Brian Levine (Vanguard emulator)
		Brad Oliver (MAME driver)
		Mirko Buffoni (MAME driver)

	Thanks for testing and bug reporting to:
		Brian Deuel (http://coinop.vintagegaming.com)
		Till Oldemeyer (http://sys2064.emulationworld.com)


