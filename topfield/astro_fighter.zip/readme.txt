*********************************************************
*                                                       *
*   Astro Fighter Emulator for the Topfield TF4000PVR   *
*                                                       *
*********************************************************
*                                                       *
*   Written by Norbert Kehrer in April 2006             *
*                                                       *
*   http://web.utanet.at/nkehrer                        *
*   norbert_kehrer@yahoo.de                             *
*                                                       *
*********************************************************



Warnings

	This program comes with absolutely no warranty.
	It can destroy your recordings, your settings, or
	even the whole set top box. So, use it at your
	own risk and do not ask me for help or complain,
	if something is wrong with your box afterwards.
	But it is the same as usual: No risk, no fun!

	The program only works on the Topfield TF4000PVR.
	It will not run on other digital satellite receivers,
	especially not on the Topfield TF5000PVR, which has
	a different CPU core.



About This Program

	Astro Fighter is an old arcade game, in which you have to
	shoot down all the enemy fighters. There are several levels
	to master before you get to kind of a boss level.

	Compared to today's games Astro Fighter uses simple graphics,
	and has a simple gameplay. Nonetheless, I like the game,
	because it was one of the first arcade games I ever played.

	Astro Fighter was made by DECO (Data East Corporation) in 1980.
	It uses the famous 6502 as its CPU and has special video and
	sound hardware.

	This emulator simulates the behavior of the hardware of the
	Astro Fighter machine on your Topfield TF4000PVR satellite
	receiver. In this way, DECO's original program from 1980 can
	be interpreted, and the result is a faithful reproduction of
	the original game on your TV screen. 
	
	This program is a so-called TAP, a plug-in for Topfield's
	satellite receiver. It is based on the unpublished
	TAP API, which was reverse-engineered by PeN (great work).



How to Run the Astro Fighter Emulator

	Download the TAP uploader application from 
	http:/www.topfield.de/ or http://www topfield.co.kr.

	Transfer the file "af.bin" to the box using TAP downloader.
	Make sure that the file type switch is in the "program" 
	position, and that "tap name" is set to "af.tap".

	Start the TAP using the "0" key on your remote control.



How to Play the Game

	The game is controlled with the remote control. Before
	being able to play, you have to "insert a coin". This is
	done with the "3" key on your remote control. After
	starting the game with "1" or "2", you use the keys for
	volume control (move fighter ship left and right) and
	the "OK" button (fire) to play. Press "Exit" to stop
	the emulator.



Known bugs
	
	The controls do not work correctly. Sometimes a key gets "stuck".
	In many cases, pressing the stuck key again or pressing "OK" helps.
	I am working on this.

	The speed of the is not emulated exactly.

	Sound is not yet emulated. Does anyone know how to play a PCM
	file on the TF4000PVR? There does not seem to be an API call.



Contact
	
	For feedback on this program, write me an email:
	norbert_kehrer@yahoo.de



Norbert Kehrer

Austria, April 16, 2006.




