**********************************************************
*                                                        *
*   Space Invaders Emulator for the Topfield TF4000PVR   *
*                                                        *
**********************************************************
*                                                        *
*   Written by Norbert Kehrer in April 2006              *
*                                                        *
*   http://web.utanet.at/nkehrer                         *
*   norbert_kehrer@yahoo.de                              *
*                                                        *
**********************************************************



Warnings

	This program comes with absolutely no warranty.
	It can destroy your recordings, your settings, or
	even the whole set top box. So, use it at your
	own risk and do not ask me for help or complain,
	if something is wrong with your box afterwards.
	But it is the same as usual: No risk, no fun!

	The program only works on the Topfield TF4000PVR.
	It will not run on other digital satellite receivers,
	especially NOT on the Topfield TF5000PVR, which has
	a different CPU core.



About This Program

	Space Invaders is one of the great classic video games. In 1978,
	when it came out, it defined its own genre and was extremely
	successful in the arcades all over the world. 

	Space Invaders was made by Midway. It used Intel's 8080 as its CPU
	and had custom-made bitmapped video hardware. This video hardware
	could only generate black and white screen output. A transparent
	screen overlay colored certain areas in green and red.

	This emulator simulates the behavior of the hardware of the
	Space Invaders machine on your Topfield TF4000PVR satellite
	receiver. In this way, Midway's original program from 1978 can
	be interpreted, and the result is a faithful reproduction of
	the original game on your TV screen. 
	
	This program is a so-called TAP, a plug-in for Topfield's
	satellite receiver. It is based on the unpublished
	TAP API, which was reverse-engineered by PeN (great work).



How to Run the Emulator

	Download the TAP uploader application from 
	http:/www.topfield.de/ or http://www topfield.co.kr.

	Transfer the file "invaders.bin" to the box using the TAP uploader.
	Make sure that the file type switch is in the "program" 
	position, and that "tap name" is set to "invaders.tap".

	Start the TAP using the "0" key on your remote control.



How to Play the Game

	The game is controlled with the remote control. Before
	being able to play, you have to "insert a coin". This is
	done with the "3" key on your remote control. After
	starting the game with "1" or "2", you use the keys for
	volume control (move fighter ship left and right) and
	the "OK" button (fire) to play. Press "Exit" to stop
	the emulator.



Known bugs
	
	The controls do not work correctly. Sometimes a key gets "stuck".
	In many cases, pressing the stuck key again or pressing "OK" helps.
	I am working on this.

	The speed of the original machine is not emulated exactly.

	Sound is not yet emulated. Does anyone know how to play a PCM
	file on the TF4000PVR? There does not seem to be an API call.



Contact
	
	For feedback on this program, write me an email:
	norbert_kehrer@yahoo.de



Norbert Kehrer

Austria, April 20, 2006.




